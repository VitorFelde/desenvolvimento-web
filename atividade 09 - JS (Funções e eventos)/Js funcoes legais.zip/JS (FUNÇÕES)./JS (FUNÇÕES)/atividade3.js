function mudarCor (cor) {
  document.getElementById("teste").style.backgroundColor = cor;  
  return cor;
} 

